import ui.LoginFrame;

public class App {
    public static void main(String[] args) {
        LoginFrame.main(args);
    }
}
